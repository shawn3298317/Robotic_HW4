#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include "opencv.hpp"
// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "4000"

using namespace std;
using namespace cv;
vector<Vec3d> translatePosition( vector<Vec3d> positions ){
	double scalarX = 276 /231.207;
	double scalarY = -57 / 50.962;
	double offsetX = 173 - 408.879*scalarX;
	double offsetY = 321 - 267.535*scalarY;
	vector<Vec3d> pos;

	for( int i = 0; i < positions.size(); i++ ){
		double deg = (-1* positions[i][2] * 180 / 3.141519265359 < 0)?(-1* positions[i][2] * 180 / 3.141519265359 + 180):-1* positions[i][2] * 180 / 3.141519265359;
		pos.push_back( Vec3d( positions[i][0]*scalarX+offsetX,
			positions[i][1]*scalarY+offsetY, deg ) );
	}
	return pos;
}


vector<Vec3d> calcPos( string path){
	cv::Mat sourceImage,src_gray, modImage;
    int thresh = 100;
    int max_thresh = 255;
    RNG rng(12345);
    
    sourceImage = cv::imread(path.c_str()); // Load a gray scale picture.
    if (!sourceImage.data)
        exit(1); //can't open, then exit

    cv::Rect crop(22,0,540,380);
    cv::Mat srcImg = sourceImage(crop);
    
    cvtColor( srcImg, src_gray, CV_BGR2GRAY );
    blur( src_gray, src_gray, Size(3,3) );
    
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    
    /// Detect edges using canny
    Canny( src_gray, modImage, thresh, thresh*2, 3 );
    /// Find contours
    findContours( modImage, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );
    
	//calc moments

	vector<Moments> mom;
	for( int j = 0; j< contours.size(); j++){
		mom.push_back(moments(contours[j]));
	}

	
    /// Draw contours
    Mat drawing = Mat::zeros( modImage.size(), CV_8UC3 );
	//namedWindow( "Contours", CV_WINDOW_AUTOSIZE );
	//namedWindow( "Src", CV_WINDOW_AUTOSIZE );

	vector<Vec3d> centroids;
    for( int i = 0; i< contours.size(); i++ )
    {
		cout<<mom[i].m00<<endl;
		//if(mom[i].m00>10){
		if(contours[i].size()>10){
		cout<<contours[i].size()<<endl;
			Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
			drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, Point() );
		}
		//centroid
		Vec3d tempC = Vec3d( mom[i].m10 / mom[i].m00, mom[i].m01 / mom[i].m00,
			 0.5 * atan2( 2 * mom[i].mu11, mom[i].mu20 - mom[i].mu02 ) );
		bool add = true;
		for( int j = 0; j < centroids.size(); j++){
			double distX = abs(centroids[j][0] - tempC[0]);
			double distY = abs( centroids[j][1] - tempC[1] );
			if( pow(distX, 2) + pow(distY, 2) < 1000){
				add = false;
			}

		}
		if( add && contours[i].size()>10 ) {
			centroids.push_back( tempC );
			cout<<"Centroid "<<tempC[0]<<","<<tempC[1]<<","<<tempC[2]<<endl;
			//drawing
			circle( srcImg, Point2d( tempC[0], tempC[1] ), 100, Scalar(255, 0, 0) );
			Point2d x0 = Point2d( 0, tempC[1] - tan( tempC[2] ) * tempC[0] );
			Point2d x1 = Point2d( srcImg.cols, tempC[1] + tan(tempC[2]) * (srcImg.cols - tempC[0] ));
			line( srcImg, x0, x1, Scalar(255,0,0) );
			cout<<"add"<<endl;
		}
	imshow( "Contours", drawing );
	imshow( "Src", srcImg );
	waitKey();
    }
	cout<<"Size: "<< centroids.size() <<endl;

	return translatePosition(centroids);
}

int sendCommand(char* sendbuf, SOCKET& ClientSocket, char* result=NULL)
{
	cout << "Sending Command: " << sendbuf << endl;
	int SendResult = 0;
	int ReceiveResult = 0;
	char recvbuf[512];
	int counter = 0;
	int RoundThreshold = 1000;
	

	//Send Command to Robot Arm
	SendResult = send(ClientSocket, sendbuf, strlen(sendbuf)+1, 0 );

    if (SendResult == SOCKET_ERROR)
	{
		cout<< "send failed with error: " << WSAGetLastError() << endl;
		closesocket(ClientSocket);
		WSACleanup();
		return 1;
	}

	Sleep(100);

	do
	{
		ReceiveResult = recv(ClientSocket, recvbuf, 512, 0);
		for(int i=0; i<ReceiveResult; i++){
			cout<<(int)recvbuf[i]<<" ";
		}
		cout<<endl;
		counter++;
	}while(ReceiveResult == 0 && counter < RoundThreshold);
	//cout<< recvbuf <<endl;
	//result = recvbuf;

	if(counter > RoundThreshold)
	{
		cout << "Respond Time Out" << endl;
		return 1;
	}
	else
	{
		if(!strcmp(recvbuf,"ERR"))
		{
			cout << "Invalid Command" << endl;
			return 1;
		}
	}

	return 0;
}

void TakePic(SOCKET* ClientSocket){
	sendCommand("VS_OPEN", *ClientSocket);
	sendCommand("VS_QUERYFRAME", *ClientSocket);	
	sendCommand("VS_SHOW", *ClientSocket);
	sendCommand("VS_SAVE C:/pic.jpg", *ClientSocket);
	Sleep(1000);
	sendCommand("VS_CLOSE", *ClientSocket);
}

int __cdecl main(void) 
{
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;
    SOCKET ClientSocket = INVALID_SOCKET;

    struct addrinfo *result = NULL;
    struct addrinfo hints;

    int recvbuflen = DEFAULT_BUFLEN;
    
    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
    if ( iResult != 0 ) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return 1;
    }

    // Create a SOCKET for connecting to server
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    // Setup the TCP listening socket
    iResult = bind( ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // Accept a client socket
    ClientSocket = accept(ListenSocket, NULL, NULL);
    if (ClientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // No longer need server socket
    closesocket(ListenSocket);
	
	//========== Add your code below ==========//
	
	// 1. Read the camera frames and open a window to show it.

	// 2. Segment the object(s) and calculate the centroid(s) and principle angle(s).

	// 3. Use prespective transform to calculate the desired pose of the arm.

	// 4. Move the arm to the grasping pose by sendCommand() function.
	// The following lines give an example of how to send a command.
	// You can find commends in "Robot Arm Manual.pdf", chap 3, section O-(5)
	char command[] = "GOHOME";
	sendCommand(command, ClientSocket);

	TakePic(&ClientSocket);
	Sleep(5000);
	vector<Vec3d> coord = calcPos("C:/pic.jpg");
	double cubex[4];
	double cubey[4];
    double angle[4];
	
	for(int i =0;i<coord.size();++i){
		cubex[i] = coord[i][0];
		cubey[i] = coord[i][1];
		angle[i] = coord[i][2];
	}

	
	// 5. Control the gripper to grasp the object.
	// The following lines give an example of how to control the gripper.
	char closeGripper[] = "OUTPUT 48 ON";
	Mat frame;
	//sendCommand(closeGripper, ClientSocket);
	Sleep(1000);
	char openGripper[] = "OUTPUT 48 OFF";
	char* pic = 0;
	//sendCommand(openGripper, ClientSocket);
	
	double x0 =cubex[0], y0=cubey[0];
	int z0=-243.5;
	sendCommand("SETLINESPEED 30", ClientSocket);
	sendCommand("MOVP # # # # 0 #", ClientSocket);
    string movp;
	int block = 1;
	while(block < coord.size()){
        stringstream mov,mov1, pile, high;
		double x,y,ang;
		x= cubex[block];
		y= cubey[block];
		ang = angle[block];
		char GripCube[]= "";
		char GripCube1[]= "";
		char Pile[]= "";
        movp = "MOVP ";
		//move  x and y first :
		mov<<x<<" "<<y<<" 120 "<<ang<<" 0 #";
		movp+=mov.str();
        strcpy(GripCube, movp.c_str());
		cout<<"GripCube"<<GripCube<<endl;
		sendCommand(GripCube, ClientSocket); 
		sendCommand("WAITMOTION", ClientSocket);
		//move z:
		
		  
		sendCommand("MOVP # # -243.5 # # #", ClientSocket); 
		sendCommand("WAITMOTION", ClientSocket);
		printf("close gripper");
		sendCommand(closeGripper, ClientSocket);
        
	
		sendCommand("MOVP # # 120 # # #", ClientSocket);
		
		sendCommand("WAITMOTION", ClientSocket);
 
        movp = "MOVP ";
		z0 = z0 + 43;
		pile<<x0<<" "<<y0<<" "<<z0<<" "<<angle[0]<<" 0 #";
		movp+=pile.str();
        strcpy(Pile, movp.c_str());
		sendCommand(Pile, ClientSocket);
		sendCommand("WAITMOTION", ClientSocket);
		sendCommand(openGripper, ClientSocket);
        
		sendCommand("MOVP # # 120 # # #", ClientSocket);
		sendCommand("WAITMOTION", ClientSocket);
		block+=1;

	}

		
		//Sleep(3000);
	
	
	//========== Add your code above ==========//
		
	

	system("pause"); 
		
	// shutdown the connection since we're done
    iResult = shutdown(ClientSocket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        printf("shutdown failed with error: %d\n", WSAGetLastError());
        closesocket(ClientSocket);
        WSACleanup();
        return 1;
    }

    // cleanup
    closesocket(ClientSocket);
    WSACleanup();

    return 0;
}
