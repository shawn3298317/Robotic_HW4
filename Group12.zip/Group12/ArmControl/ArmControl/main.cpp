#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include "opencv.hpp"
// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "4000"

using namespace std;
using namespace cv;

int sendCommand(char* sendbuf, SOCKET& ClientSocket, char* result=NULL)
{
	cout << "Sending Command: " << sendbuf << endl;
	int SendResult = 0;
	int ReceiveResult = 0;
	char recvbuf[512];
	int counter = 0;
	int RoundThreshold = 1000;
	

	//Send Command to Robot Arm
	SendResult = send(ClientSocket, sendbuf, strlen(sendbuf)+1, 0 );

    if (SendResult == SOCKET_ERROR)
	{
		cout<< "send failed with error: " << WSAGetLastError() << endl;
		closesocket(ClientSocket);
		WSACleanup();
		return 1;
	}

	Sleep(100);

	do
	{
		ReceiveResult = recv(ClientSocket, recvbuf, 512, 0);
		for(int i=0; i<ReceiveResult; i++){
			cout<<(int)recvbuf[i]<<" ";
		}
		cout<<endl;
		counter++;
	}while(ReceiveResult == 0 && counter < RoundThreshold);
	//cout<< recvbuf <<endl;
	//result = recvbuf;

	if(counter > RoundThreshold)
	{
		cout << "Respond Time Out" << endl;
		return 1;
	}
	else
	{
		if(!strcmp(recvbuf,"ERR"))
		{
			cout << "Invalid Command" << endl;
			return 1;
		}
	}

	return 0;
}

int __cdecl main(void) 
{
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;
    SOCKET ClientSocket = INVALID_SOCKET;

    struct addrinfo *result = NULL;
    struct addrinfo hints;

    int recvbuflen = DEFAULT_BUFLEN;
    
    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
    if ( iResult != 0 ) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return 1;
    }

    // Create a SOCKET for connecting to server
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    // Setup the TCP listening socket
    iResult = bind( ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // Accept a client socket
    ClientSocket = accept(ListenSocket, NULL, NULL);
    if (ClientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // No longer need server socket
    closesocket(ListenSocket);
	
	//========== Add your code below ==========//
	
	// 1. Read the camera frames and open a window to show it.

	// 2. Segment the object(s) and calculate the centroid(s) and principle angle(s).

	// 3. Use prespective transform to calculate the desired pose of the arm.

	// 4. Move the arm to the grasping pose by sendCommand() function.
	// The following lines give an example of how to send a command.
	// You can find commends in "Robot Arm Manual.pdf", chap 3, section O-(5)
	char command[] = "GOHOME";
	sendCommand(command, ClientSocket);
	
	// 5. Control the gripper to grasp the object.
	// The following lines give an example of how to control the gripper.
	char closeGripper[] = "OUTPUT 48 ON";
	Mat frame;
	sendCommand(closeGripper, ClientSocket);
	Sleep(1000);
	char openGripper[] = "OUTPUT 48 OFF";
	char* pic;
	sendCommand(openGripper, ClientSocket);
	float cubex[2] ={ -16.93, 148.68};
	float cubey[2]={34.012,34.012};
	float cubez[2]={-242.1,-243.3};
	float x0 =cubex[0], y0=cubey[0], z0=cubez[0], zhigh;
	
	sendCommand("SETLINESPEED 18", ClientSocket);
	sendCommand("MOVP # # # # 0 #", ClientSocket);

	for(int i=1; i<2;i++){
		
		stringstream mov, pile, high ;
		cout<<"ENTERRRRR THEEEE LOOOOP"<<endl;
		float x = cubex[i], y= cubey[i], z= cubez[i];
		string GripCube= "MOVP ";
		string Pile= "MOVP ";
		string High= "MOVP ";
		mov<<x<<" "<<y<<" "<<z;
		mov>>GripCube;
		z0=z0+i*40;
		pile<<x0<<" "<<y0<<" "<<z0;
		pile>>Pile;
		cout<<GripCube<<endl;
		//sendCommand(GripCube, ClientSocket);
		sendCommand(closeGripper, ClientSocket);
		zhigh = z+400;
		high<<x<<" "<<y<<" "<<zhigh;
		high>>High;
		cout<<High<<endl;
		//sendCommand(High, ClientSocket);
		cout<<Pile<<endl;
		//sendCommand(Pile, ClientSocket);
		sendCommand(openGripper, ClientSocket);

	}

		
		//Sleep(3000);
	
	sendCommand("VS_OPEN", ClientSocket);
	//cout<< "Pic\n" <<pic <<endl;
	//cv::Mat
	//sendCommand("STACK_CLEAR", ClientSocket, pic);
	{
		sendCommand("VS_QUERYFRAME", ClientSocket);	
		sendCommand("VS_SHOW", ClientSocket);
		sendCommand("VS_SAVE C:/1.bmp", ClientSocket, pic);
		Sleep(1000);
	}
	sendCommand("VS_CLOSE", ClientSocket);
	//========== Add your code above ==========//
		
	//sendCommand("MOVP 40 10 100 # # #", ClientSocket);	

	system("pause"); 
		
	// shutdown the connection since we're done
    iResult = shutdown(ClientSocket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        printf("shutdown failed with error: %d\n", WSAGetLastError());
        closesocket(ClientSocket);
        WSACleanup();
        return 1;
    }

    // cleanup
    closesocket(ClientSocket);
    WSACleanup();

    return 0;
}
