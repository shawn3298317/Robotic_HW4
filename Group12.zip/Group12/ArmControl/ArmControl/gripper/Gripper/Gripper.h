#ifndef GRIPPER_H
#define GRIPPER_H
#include "RS232.h"

using namespace std;

void GripperTurnOn();
void GripperOpen();
void GripperClose();

#endif